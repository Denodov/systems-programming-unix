#include "funs.h"

int fun2(int num) {
    return num + 1;
}

float fun3(int num) {
    return (float)num / 2.0f;   // key: 2.0f forces float division
}
